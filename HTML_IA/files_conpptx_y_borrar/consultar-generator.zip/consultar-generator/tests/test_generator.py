"""
test_generator.py
===================
Pruebas de extremo a extremo: cargar → validar → renderizar → escribir.
Usan el `config.yaml` real del proyecto para comprobar que el generador
completo produce un archivo HTML coherente, y comprueban también que un
error de validación NO deja ningún archivo a medio escribir.
"""
import re
import tempfile
import unittest
from pathlib import Path

from generator.generator import ErrorDeGeneracion, generar_aplicacion

RUTA_CONFIG_REAL = Path(__file__).resolve().parent.parent / "config.yaml"


class TestGeneracionCompleta(unittest.TestCase):
    def setUp(self) -> None:
        self._directorio_temporal = tempfile.TemporaryDirectory()
        self.directorio_salida = Path(self._directorio_temporal.name)

    def tearDown(self) -> None:
        self._directorio_temporal.cleanup()

    def test_genera_un_archivo_html_valido(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        self.assertIsNotNone(ruta_salida)
        self.assertTrue(ruta_salida.exists())
        self.assertEqual(ruta_salida.suffix, ".html")

        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertTrue(contenido.startswith("<!DOCTYPE html>"))
        self.assertIn('<html lang="es">', contenido)
        self.assertIn("ConSultar", contenido)

    def test_no_quedan_etiquetas_jinja_sin_resolver(self) -> None:
        """Cualquier '{%' indica una plantilla mal cerrada; los '{{marcador}}'
        legítimos de los prompts (p. ej. '{{consulta}}') SÍ deben permanecer,
        ya que los sustituye la aplicación generada en el navegador, no el
        generador Python."""
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertNotIn("{%", contenido)
        self.assertNotIn("{#", contenido)
        # Los marcadores de prompt sí deben seguir presentes:
        self.assertIn("{{consulta}}", contenido)

    def test_incluye_las_dependencias_por_defecto(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        urls = re.findall(r'<script src="([^"]+)">', contenido)
        # marked, DOMPurify, docx, jsPDF, mammoth, pdf.js y PptxGenJS con la
        # configuración por defecto (todos los formatos de exportación, de
        # adjuntos y la generación de PowerPoint activos).
        self.assertEqual(len(urls), 7)

    def test_modo_validate_no_escribe_archivo(self) -> None:
        resultado = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida, solo_validar=True)
        self.assertIsNone(resultado)
        self.assertEqual(list(self.directorio_salida.glob("*")), [])

    def test_configuracion_invalida_no_genera_archivo_parcial(self) -> None:
        with tempfile.TemporaryDirectory() as directorio_config:
            ruta_config_mala = Path(directorio_config) / "config.yaml"
            ruta_config_mala.write_text("aplicacion:\n  nombre: ''\n", encoding="utf-8")

            with self.assertRaises(ErrorDeGeneracion):
                generar_aplicacion(ruta_config_mala, directorio_salida_override=self.directorio_salida)

            self.assertEqual(list(self.directorio_salida.glob("*")), [])

    def test_modelo_html_select_contiene_los_modelos_configurados(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertIn("Claude Sonnet 5", contenido)
        self.assertIn("Claude Opus 4.1 (legacy)", contenido)

    def test_campo_de_adjuntos_presente_por_defecto(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertIn('id="adjuntos-input"', contenido)
        self.assertIn("mammoth", contenido)
        self.assertIn("pdf.js", contenido)
        self.assertIn("{{documentos_adjuntos}}", contenido)

    def test_campo_de_guardar_prompts_presente_por_defecto(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertIn('id="guardar-prompts-checkbox"', contenido)
        self.assertIn('id="guardar-prompts-btn"', contenido)
        self.assertIn('id="nombre-archivo-prompts-input"', contenido)

    def test_aviso_de_truncamiento_presente_por_defecto(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertIn('id="aviso-truncado"', contenido)
        self.assertIn("stop_reason", contenido)
        self.assertIn("max_tokens", contenido)

    def test_boton_generar_powerpoint_presente_por_defecto(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertIn('id="generar-pptx-btn"', contenido)
        self.assertIn("pptxgenjs", contenido)
        self.assertIn("consultor experto en diseño de presentaciones", contenido)

    def test_botones_borrar_presentes_por_defecto(self) -> None:
        ruta_salida = generar_aplicacion(RUTA_CONFIG_REAL, directorio_salida_override=self.directorio_salida)
        contenido = ruta_salida.read_text(encoding="utf-8")
        self.assertIn('id="borrar-rol-btn"', contenido)
        self.assertIn('id="borrar-consulta-btn"', contenido)
        self.assertIn('id="borrar-resultado-btn"', contenido)
        self.assertIn("function validarPaqueteDocx", contenido)


if __name__ == "__main__":
    unittest.main()
